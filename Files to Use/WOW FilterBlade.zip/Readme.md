To use this filter, you need to add the key into your SCRIPTDIR/save/settings.ini
Paste at the end of the file if you do not already have the key in your settings
When Complete the entry should look like this:

[Loot Colors]
LootColors=0xF2F2F2,0xC8C8C8,0x224522,0x001600,0x222245,0x000016,0x452222,0x160000


If you want to make adjustments to this base filter:
[WoW FilterBlade](https://www.filterblade.xyz/?profile=throwawaysfortheplebs&saveState=UQ8598DKEMYZC2&platform=pc)

Or search PLEB on the plugin authors to use the color preset which matches